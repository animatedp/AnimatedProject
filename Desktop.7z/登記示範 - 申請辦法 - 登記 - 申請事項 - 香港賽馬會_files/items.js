//Edited by DCHK at 18-3-2009 11:40am 

var tempHtml;
var tempStr1;
var tempStr2;
if (section == null)	var section = 0;
if (level1 == null)	var level1 = "";
if (level2 == null)	var level2 = "";
if (level3 == null)	var level3 = "";
if (level4 == null)	var level4 = "";
if (selectArray == null)	var selectArray = null;
var id1 = null;
var id2 = null;
var id3 = null;
var id4 = null;

if (location.search != '')
{
	if (GetParam('section'))	section = GetParam('section');
	if (GetParam('level1'))	level1 = GetParam('level1');
	if (GetParam('level2'))	level2 = GetParam('level2');
	if (GetParam('level3'))	level3 = GetParam('level3');
	if (GetParam('level4'))	level4 = GetParam('level4');
}

var titlePadding = 12;
var titleSubTitle = "";
var treeLinkSubTitle = "";
var treeLinkPadding = 10;
var treeLinkLink = "";

//getLevel();
//genId();
function genDivs(divID)
{
	if (!document.getElementById(divID))
		{
			document.write('<span id="'+divID+'" ></span>');
		}
}

function getLevel() {
	var link = location.href.toString();
	var obj = sectionArray[section];
	
	function checkStr(astr, bstr)
		{
			var va = [".", "/", "_"];
			for (var item in va)
				{
					if (astr.indexOf(("/" + bstr + va[item])) > -1)
						{
							return true;
						}
				}
			return false;
		}
	
	if (level1 == "") {
		for (var i=0; i<obj.length; i++) {
			//if (link.indexOf(("/" + obj[i].id + "/")) > -1) {
			if (checkStr(link, obj[i].id)) {
				level1 = obj[i].id;
				
				if (level2 == "" && obj[i].subSection) {
					var obj1 = obj[i].subSection;
					
					for (var j=0; j<obj1.length; j++) {
						//if (link.indexOf(("/" + obj1[j].id)) > -1) {
						if (checkStr(link, obj1[j].id)) {
							level2 = obj1[j].id;
							
							if (level3 == "" && obj1[j].subSection) {
								var obj2 = obj1[j].subSection;
								
								for (var k=0; k<obj2.length; k++) {
									//if (link.indexOf(("/" + obj2[k].id)) > -1) {
									if (checkStr(link, obj2[k].id)) {
										level3 = obj2[k].id;
										
										if (level4 == "" && obj2[k].subSection) {
											var obj3 = obj2[k].subSection;
											
											for (var m=0; m<obj3.length; m++) {
												//if (link.indexOf(("/" + obj3[m].id)) > -1) {
												if (checkStr(link, obj3[m].id)) {
													level4 = obj3[m].id;
													
													break;
												}
											}
										} else {
											break;
										}
									}
								}
							} else {
								break;
							}
						}
					}
				} else {
					break;
				}
			}
		}
	}
}

function genId() {	
	var obj = sectionArray[section];
	if (level1 != "") {
		for (var i=0; i<obj.length; i++) {
			if (obj[i].id == level1) {
				id1 = i;
				
				if (level2 != "") {
					var obj1 = obj[i].subSection;
					
					for (var j=0; j<obj1.length; j++) {
						if (obj1[j].id == level2) {
							id2 = j;
							
							if (level3 != "") {
								var obj2 = obj1[j].subSection;
							
								for (var k=0; k<obj2.length; k++) {
									if (obj2[k].id == level3) {
										id3 = k;
										if (level4 != "") {
											var obj3 = obj2[k].subSection;
										
											for (var m=0; m<obj3.length; m++) {
												if (obj3[m].id == level4) {
													id4 = m;
													break;
												}
											}
										} else {
											break;
										}
									}
								}
							} else {
								break;
							}
						}
					}
				} else {
					break;
				}
			}
		}
	}
}

function elem(tag, content){ 
	var ret = document.createElement(tag);  
	ret.innerHTML = content;  
	return ret;
}

function genTop() {
	if (genTop.caller == null)
		{
			genDivs("topNavDiv");
			//document.write('<span id="topNavDiv" ></span>');
			return;
		}
		
	tempHtml = '';
	
	//tempHtml += '<div style="position:absolute;">';
	
	genNav();
	
	tempHtml += '<table width="750" border="0" cellspacing="0" cellpadding="0" id="header">';
	tempHtml += '	<tr>';
	tempHtml += '		<td height="83" bgcolor="#003B7E">';
	tempHtml += '			<table width="100%" height="83" border="0" cellspacing="0" cellpadding="0">';
	tempHtml += '				<tr>';
	tempHtml += '					<td style="padding:5px 0px 5px 15px;"><img src="'+path+'images/hkjc_logo.png" width="145" height="60" alt="The Hong Kong Jockey Club"></td>';
	tempHtml += '					<td valign="top" align="right" class="topNav" style="padding:5px 15px 0px 0px;" id="topRightNav">�r��<a href="javascript:changeFontSize(\'contentTable\', 1);"><img src="'+path+'images/icon_add.gif" width="9" height="9" border="0" align="absmiddle" hspace="4" alt="�r���j"></a><a href="javascript:changeFontSize(\'contentTable\', -1);"><img src="'+path+'images/icon_dec.gif" width="9" height="9" border="0" align="absmiddle" alt="�r���p"></a><img src="'+path+'images/stroke_1.gif" width="1" height="9" hspace="12" align="absmiddle"><a href="javascript:print();" class="topNav"><img src="'+path+'images/icon_print.gif" width="11" height="11" border="0" align="absmiddle" alt=""> �C�L</a><img src="'+path+'images/stroke_1.gif" width="1" height="9" hspace="12" align="absmiddle"><a href="javascript:changeLanguage();" class="topNav" style="font-size:10px;"><img src="'+path+'images/arrow_1.gif" width="4" height="6" border="0" align="abstop" alt=""> ENGLISH</a></td>';
	tempHtml += '				</tr>';
	tempHtml += '			</table>';
	tempHtml += '		</td>';
	tempHtml += '	</tr>';
	tempHtml += '	<tr>';
	tempHtml += '		<td height="7" bgcolor="#BDBDBD"><img src="'+path+'images/spacer.gif" width="1" height="7"></td>';
	tempHtml += '	</tr>';
	tempHtml += '</table>';
	
	//Header for Print
	tempHtml += '<table width="750" border="0" cellspacing="0" cellpadding="0" id="headerPrint">';
	tempHtml += '<tr>';
	tempHtml += '<td><img src="'+path+'images/header.gif"></td>';
	tempHtml += '</tr>';
	tempHtml += '</table>';
	
	document.getElementById('topNavDiv').innerHTML = tempHtml;
}

function genFooter() {
	document.write('<link rel="stylesheet" href="../css/footer.css">');

	var str = '';

	str += '<div id="footer" style="width:730px;margin-left:5px;color:#00326F">';
	str += '	<div class="rgp">';
	str += '<img src="/infomenu/ch/images/rgp_text_chi_710.gif" usemap="#RGP_710c" border="0" alt="" />';
	str += '	</div>';
	str += '	<div class="nav clearfix">';
	str += '	 	<div class="content"><a href="javascript:NewWindow(\'http://www.hkjc.com/chinese/corporate/faq.asp\',\'mypopup\',\'770\',\'550\',\'yes\',\'yes\');" class="first">�`�����D</a>  |  <a href="javascript:NewWindow(\'http://special.hkjc.com/infomenu/ch/contact/feedback.asp\',\'mypopup\',\'770\',\'550\',\'yes\',\'yes\');">�p���ڭ�</a>  |  <a href="javascript:NewWindow(\'http://mcs.hkjc.com/\',\'mypopup\',\'770\',\'550\',\'yes\',\'yes\');">�ǴC�M�ΰ�</a>  |  <a href="http://www.hkjc.com/chinese/corporate/corp_sitemap.asp">�������n</a>  |  <a href="javascript:NewWindow(\'http://www.hkjc.com/chinese/betting/betting_rule.htm\',\'mypopup\',\'770\',\'550\',\'yes\',\'yes\');"> �W��</a>  |  <a href="http://www.hkjc.com/chinese/corporate/corp_rgpolicy_generic.asp">���Ҧ��`��ձm</a>  |  <a href="http://www.hkjc.com/chinese/corporate/corp_privacy.asp">�p������</a>  |  <a href="http://www.hkjc.com/chinese/corporate/corp_disclaimer.asp">�K�d�n��</a></div>';
	str += '		<br><div class="copyright">���v�Ҧ� ���o��� &copy; 2000-2018 �����ɰ��|</div>';
	str += '	</div>';
	str += '</div>';
	str += '<map name="RGP_710c" id="RGP_710c">'
	str += '<area shape="rect" coords="641,1,709,42" href="http://corporate.hkjc.com/corporate/rgp/chinese/index.aspx" target="_blank" />'
	str += '</map>'

	document.write(str);
	
	getFontSize("contentTable");
	
	/*<!-- START WA Tagging -->*/
	document.write('<scr' + 'ipt type="text/javascript" src="//common.hkjc.com/wa/wa_tracker.js"></scr'+'ipt>');
	document.write('<scr' + 'ipt type="text/javascript" src="//common.hkjc.com/wa/wa_tracker_config.js"></scr'+'ipt>');
	setTimeout(function()
	{
	  try {
		WATracker.trackPageView('bet-infomenu');
	  } catch (e) {}
	},500);
	/*<!-- END WA Tagging -->*/
}

function genLeftStart() {
	if (genLeftStart.caller == null)
		{
			genDivs("leftNavDiv");
			return;
		}

	tempHtml = '';
	
	tempHtml += '<table width="750" border="0" cellspacing="0" cellpadding="0">';
	tempHtml += '	<tr>';
	tempHtml += '		<td style="padding:15px 0px 5px 0px;">';
	tempHtml += '			<table width="100%" height="300" border="0" cellspacing="0" cellpadding="0">';
	tempHtml += '				<tr valign="top">';
	tempHtml += '					<td width="160" id="leftNav">';
	
	genLeft();
	
	tempHtml += '					</td>';
	tempHtml += '					<td id="rightTD">';
	
	document.getElementById('leftNavDiv').innerHTML = tempHtml;
}

function genLeftEnd() {
	tempHtml = '';
	
	tempHtml += '</td>';
	tempHtml += '				</tr>';
	tempHtml += '			</table>';
	tempHtml += '		</td>';
	tempHtml += '	</tr>';
	tempHtml += '</table>';
	
	document.write(tempHtml);
}

function genTopBtn() {
	tempHtml = '';
	
	tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="0" id="topBtn">';
	tempHtml += '	<tr>';
	tempHtml += '		<td align="right" style="padding:20px 15px 5px 0px;" class="functionTxt">';
	tempHtml += '<img src="'+path+'images/arrow_top.gif" width="6" height="4" hspace="4" align="absmiddle"><a href="#top">�^�쭶��</a>';
	tempHtml += '</td>';
	tempHtml += '	</tr>';
	tempHtml += '</table>';
	
	document.write(tempHtml);
}

function genLeft() {
	var obj = sectionArray[section][id1];
	var obj1 = obj.subSection;

	tempHtml += '<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">';
	tempHtml += '	<tr valign="top">';
	
	if (level1 == "channel" && !(level2 == "guide" | level2 == "overview" | level2 == "investments")) {
		var img = path+level1+'/'+level2+'/images/title.gif';
		tempStr1 = 'background:url('+path+level1+'/'+level2+'/images/bg_left.jpg) no-repeat right bottom #D8E0ED;';
	} else {
		var img = path+level1+'/images/title_'+level2+'.gif';
		tempStr1 = 'background:url('+path+'images/bg_left.gif) no-repeat right bottom #D8E0ED;';
	}
	
	tempHtml += '		<td height="41" style="padding:0px 0px 14px 10px;"><a href="'+genLink(obj1[id2].link, obj1[id2].popup, obj1[id2].target)+'"><img src="'+img+'" border="0" alt="'+obj1[id2].name+'"></a></td>';
	tempHtml += '		<td align="right"><img src="'+path+'images/title_line.gif" width="2" height="26"></td>';
	tempHtml += '	</tr>';
	
	tempHtml += '	<tr valign="top">';
	tempHtml += '		<td colspan="2" style="padding:10px 3px 0px 3px;'+tempStr1+'">';
	
	if (obj1[id2].subSection.length>0) {

		var obj2 = obj1[id2].subSection;
		tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="5">';
		tempHtml += '<tr valign="top">';
		tempHtml += '	<td style="padding:0px;">';
		
		tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="5">';

		for (var k=0; k<obj2.length; k++) {
			if (id3 == k) {
				tempStr1 = 'color:#005EBC';
				isSect = 1;
			} else {
				tempStr1 = '';
				isSect = 0;
			}
			if (id3 == null) {
				tempStr2 = 'subNavOut('+k+');';
			} else {
				if (obj2[id3].subSection) {
					tempStr2 = 'subNavOver('+id3+');';
				} else {
					tempStr2 = 'subNavOut('+k+');';
				}
			}
			
			tempHtml += '<tr>';
			tempHtml += '<td style="padding:0px;">';
			tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="5" onMouseOver="subNavOver('+k+');" onMouseOut="'+tempStr2+'">';
			
			if (level1 == "cs" && level2 == "hotline" && level3 == "applicationform" 
					&& obj2[k].link == "contact/application_forms.asp") {
				tempHtml += '<tr valign="top">';
				tempHtml += '<td class="menuTxt" style="padding-left:10px;"><a href="../cs/hotline.asp" class="menuTxt" style="width:100%; height:100%;"><strong>�p���~�|</strong></a></td>';
				tempHtml += '</tr>';
			}else if(level1 == "info"  && level2 == "hotline" && level3 == "applicationform" && obj2[k].link == "contact/application_forms.asp"){
                tempHtml += '<tr valign="top">';
				tempHtml += '<td class="menuTxt" style="padding-left:10px;"><a href="../info/hotline.asp" class="menuTxt" style="width:100%; height:100%;"><strong>�p���~�|</strong></a></td>';
				tempHtml += '</tr>';
			} else {
				tempHtml += '<tr valign="top">';
				tempHtml += '<td class="menuTxt" style="padding-left:10px;"><a href="'+genLink(obj2[k].link, obj2[k].popup, obj2[k].target)+'" class="menuTxt" style="width:100%; height:100%; '+tempStr1+'"><strong>'+obj2[k].name+'</strong></a></td>';
				tempHtml += '</tr>';
			}
			
			if (obj2[k].subSection != "") {
				var obj3 = obj2[k].subSection;
				
				tempHtml += '<tr>';
				tempHtml += '<td style="padding:0px;">';
				
				tempHtml += '<div style="position:relative;">';
				tempHtml += '<div style="position:relative; overflow:hidden; left:0px; top:0px; width:150px; height:1px;" id="subNav_'+k+'">';
				
				tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="0">';
				
				tempHtml += '	<tr>';
				tempHtml += '		<td height="1"><img src="'+path+'images/spacer.gif" width="1" height="1"></td>';
				tempHtml += '	</tr>';
				tempHtml += '	<tr>';
				tempHtml += '		<td height="1" bgcolor="#B7C4D9"><img src="'+path+'images/spacer.gif" width="1" height="1"></td>';
				tempHtml += '	</tr>';
				tempHtml += '	<tr>';
				tempHtml += '		<td height="1" bgcolor="#F7F9FB"><img src="'+path+'images/spacer.gif" width="1" height="1"></td>';
				tempHtml += '	</tr>';
				tempHtml += '	<tr valign="top">';
				tempHtml += '		<td style="padding:5px 0px 5px 10px;">';
				
				tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="0">';
				
				for (var m=0; m<obj3.length; m++) {
					if (id3 == k && id4 == m) {
						tempStr1 = "color:#005EBC;";
						isSect = 1;
					} else {
						tempStr1 = "";
						isSect = 0;
					}
					
					tempHtml += '<tr valign="top">';
					tempHtml += '<td width="10" style="padding:5px 0px 0px 0px;"><img src="'+path+'images/menu_arrow.gif" width="3" height="5"></td>';
					tempHtml += '<td class="menuTxt" style="padding:0px 0px 8px 0px;"><a href="'+genLink(obj3[m].link, obj3[m].popup, obj3[m].target)+'" class="menuTxt" style="'+tempStr1+'">'+obj3[m].name+'</a></td>';
					
					tempHtml += '</tr>';
				}
				
				tempHtml += '</table>';
				
				tempHtml += '		</td>';
				tempHtml += '	</tr>';
				tempHtml += '</table>';
				
				tempHtml += '</div>';
				tempHtml += '</div>';
				
				tempHtml += '		</td>';
				tempHtml += '	</tr>';
			} else {
				tempHtml += '	<tr>';
				tempHtml += '		<td height="1" style="padding:0px;"><img src="'+path+'images/spacer.gif" width="1" height="1"></td>';
				tempHtml += '	</tr>';
			}
			
			
			tempHtml += '</table>';
			tempHtml += '	</td>';
			tempHtml += '</tr>';
			
			
			tempHtml += '	<tr>';
			tempHtml += '		<td height="1" bgcolor="#B7C4D9" style="padding:0px;"><img src="'+path+'images/spacer.gif" width="1" height="1"></td>';
			tempHtml += '	</tr>';
			tempHtml += '	<tr>';
			tempHtml += '		<td height="1" bgcolor="#F7F9FB" style="padding:0px;"><img src="'+path+'images/spacer.gif" width="1" height="1"></td>';
			tempHtml += '	</tr>';
		}
		
		
		
		tempHtml += '</table>';
		
		
		tempHtml += '	</td>';
		tempHtml += '</tr>';
		
		
		tempHtml += '<tr valign="top">';
		tempHtml += '	<td style="padding:40px 5px 15px 5px;">';
		
		
		genQuickLinks();
		
		
		tempHtml += '	</td>';
		tempHtml += '</tr>';
		
		
		tempHtml += '			</table>';
	}
	
	tempHtml += '		</td>';
	tempHtml += '	</tr>';
	
	tempHtml += '	<tr>';
	tempHtml += '		<td colspan="2" height="1"><img src="'+path+'images/spacer.gif" width="160" height="1"></td>';
	tempHtml += '	</tr>';
	tempHtml += '</table>';
}


function subNavStart(i) {
	if (document.getElementById('subNav_'+i)) {
		var obj = sectionArray[section];
		var obj1 = obj[id1].subSection;
		var obj2 = obj1[id2].subSection;
		var subNav = document.getElementById('subNav_'+i);
		
		//subNav.timeOut = "";
		subNav.style.height = subNav.scrollHeight + "px";
	}
}


var subNavTimeOut;

function subNavOver(i)
{
	//if (i == id3)	return;
	var obj = sectionArray[section];
	var obj1 = obj[id1].subSection;
	var obj2 = obj1[id2].subSection;
	
	if (document.getElementById('subNav_'+i)) {
		for (var k=0; k<obj2.length; k++) {
			if (document.getElementById('subNav_'+k)) {
				subNav = document.getElementById('subNav_'+k);
				
				if (subNavTimeOut)	clearTimeout(subNavTimeOut);
				
				if (k == i || k == id3) {
					if (navigator.appName.indexOf("Microsoft") > -1){
						subNav.tempH = subNav.scrollHeight;
					} else {
						subNav.tempH = subNav.scrollHeight;
					}
					subNav.speed = 4;
				} else {
					subNav.tempH = 1;
					subNav.speed = 4;
				}
			}
		}
		
		/*if (i == id3) {
			timeOut = setTimeout("subNavMotion()", 300);
		} else {
			clearTimeout(timeOut);
			
			subNavMotion();
		}*/
		subNavMotion();
	}
}


function subNavOut(i) {
	var obj = sectionArray[section];
	var obj1 = obj[id1].subSection;
	var obj2 = obj1[id2].subSection;
	
	if (document.getElementById('subNav_'+i)){
		subNav = document.getElementById('subNav_'+i);
		
		subNav.tempH = 1;
		subNav.speed = 4;
	}
	
	subNavTimeOut = setTimeout("subNavMotion()", 300);
}


function subNavMotion() {
	var obj = sectionArray[section];
	var obj1 = obj[id1].subSection;
	var obj2 = obj1[id2].subSection;
	
	for (var k=0; k<obj2.length; k++) {
		
		if (k == id3)	continue;
		
		if (document.getElementById('subNav_'+k)) {
			subNav = document.getElementById('subNav_'+k);
			
			if (navigator.appName.indexOf("Microsoft") > -1) {
				subNav.objH = Number(subNav.style.pixelHeight);
			} else {
				var tempH = subNav.style.height;
				tempH = Number(tempH.substring(0, (tempH.length-2)));
				subNav.objH = tempH;
			}
			
			//subNav.goStep = (subNav.tempH - subNav.objH)/subNav.speed;
			if (subNav.tempH - subNav.objH > 0)
			{
				subNav.goStep = subNav.speed;
			}
			else
			{
				subNav.goStep = -subNav.speed;
			}
			
			if (!(Math.abs(subNav.objH - subNav.tempH) < subNav.speed)) {
				subNav.objH += subNav.goStep;
			} else {
				subNav.objH = subNav.tempH;
				clearTimeout(subNavTimeOut);
			}
			subNav.style.height = subNav.objH + "px";
		}
	}
	
	subNavTimeOut = setTimeout("subNavMotion()", 20);
}


function genQuickLinks() {
	if (sectionArray[section][id1].subSection[id2].quickLinks.length > 0) {
		var obj = sectionArray[section][id1].subSection[id2].quickLinks;
		
		tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="0">';
		tempHtml += '	<tr valign="top">';
		tempHtml += '		<td class="red" colspan="2" style="padding-left:5px; padding-bottom:7px;"><strong>�ֳt���|</strong></td>';
		tempHtml += '	</tr>';
		
		for (var i=0; i<obj.length; i++) {
			tempHtml += '	<tr valign="top">';
			tempHtml += '		<td style="padding:5px 7px 0px 8px;"><img src="'+path+'images/arrow_4.gif" border="0" align="absmiddle"></td>';
			tempHtml += '		<td width="100%" class="footer" style="padding:0px 0px 4px 0px;"><a href="'+genLink(obj[i].link, obj[i].popup, obj[i].target)+'">'+obj[i].name+'</a></td>';
			tempHtml += '	</tr>';
		}
		
		tempHtml += '</table>';
	}
}


function genLogo(write) {
	if (write)	tempHtml = '';
	
	tempHtml += '<span id="logoImg"></span>';
	if (write)	document.write(tempHtml);
}


function genTitle(pad, subTitle) {
	if (pad)	
		{
			titlePadding = pad;
		}

	if (typeof(subTitle)!="undefined")	
		{
			titleSubTitle = subTitle;
		}
	if (titleSubTitle != "")
		{
			subTitle = titleSubTitle;
		}

	if (genTitle.caller == null)
		{
			genDivs("titleDiv");
			return;
		}
	
	var padding = titlePadding;
	var name;
	
	if (id1 != null) {
		var obj = sectionArray[section][id1];
		name = obj.name;
		
		if (id2 != null) {
			var obj = obj.subSection[id2];
			name = obj.name;
			
			if (id3 != null) {
				var obj = obj.subSection[id3];
				name = obj.name;
				
				if (id4 != null) {
					var obj = obj.subSection[id4];
					name = obj.name;
				}
			}
		}
	}
	
	tempHtml = '';
	
	tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="0">';
	tempHtml += '<tr valign="top">';
	tempHtml += '<td class="topTitle" style="padding:0px 0px '+padding+'px 0px;">';
	tempHtml += name;
	if (typeof(subTitle)!="undefined")	tempHtml += " - " + subTitle;
	tempHtml += '</td>';
	tempHtml += '</tr>';
	tempHtml += '</table>';
	
	document.getElementById('titleDiv').innerHTML = tempHtml;
}

function genTreeLink(pad, txt, link) {
	if (pad)	
		{
			treeLinkPadding = pad;
		}
	if (link)	
		{
			treeLinkLink = link;
		}

	if (typeof(txt)!="undefined")	
		{
			treeLinkSubTitle = txt;
		}
	if (treeLinkSubTitle != "")
		{
			txt = treeLinkSubTitle;
		}
	if (genTreeLink.caller == null)
		{
			genDivs("treeLinkDiv");
			return;
		}
	var obj = sectionArray[section];
	var obj1 = obj[id1].subSection;
	var obj2 = obj1[id2].subSection;
	var padding = 10;
//	if (pad)	padding = pad;
	
	tempHtml = '';
	
	tempHtml += '<table width="100%" border="0" cellspacing="0" cellpadding="0" id="treeLink">';
	tempHtml += '	<tr valign="top">';
	
	if (level1 == "channel" && (obj1[id2].logo == 1)) {
		tempHtml += '<td style="padding:0px 10px 0px 0px;">';
		genLogo();
		tempHtml += '</td>';
	}
	
	tempHtml += '<td width="100%" height="30" class="copyright">';
	
	var obj = sectionArray[section];
	if (id2 == null) {
		tempHtml += '<b><a href="'+genLink(obj[id1].link)+'" target="'+obj[id1].target+'">' + obj[id1].name + '</a></b>';
	} else {
		tempHtml += '<a href="'+genLink(obj[id1].link)+'" target="'+obj[id1].target+'">' + obj[id1].name + '</a>';
		tempHtml += ' > ';
		
		var obj1 = obj[id1].subSection;
		if (id3 == null) {
			if (txt) {
				tempHtml += '<a href="'+genLink(obj1[id2].link)+'" target="'+obj1[id2].target+'">' + obj1[id2].name + '</a>';
				
				if (txt)
				{
					if (treeLinkLink != "")
					{
						tempHtml += ' > <a href="'+path+treeLinkLink+'"><b>' + txt + '</b></a>';
					}
					else
					{
						tempHtml += ' > <b class="copyright">' + txt + '</b>';
					}
				}
			} else {
				tempHtml += '<b><a href="'+genLink(obj1[id2].link)+'" target="'+obj1[id2].target+'">' + obj1[id2].name + '</a></b>';
			}
		} else {
			if (obj1[id2].subSection) {
				tempHtml += '<a href="'+genLink(obj1[id2].link)+'" target="'+obj1[id2].target+'">' + obj1[id2].name + '</a>';
				tempHtml += ' > ';
				
				var obj2 = obj1[id2].subSection;
				if (id4 == null) {
					if (txt) {
						tempHtml += '<a href="'+genLink(obj2[id3].link)+'" target="'+obj2[id3].target+'">' + obj2[id3].name + '</a>';
						if (txt)
						{
							if (treeLinkLink != "")
							{
								tempHtml += ' > <a href="'+path+treeLinkLink+'"><b>' + txt + '</b></a>';
							}
							else
							{
								tempHtml += ' > <b class="copyright">' + txt + '</b>';
							}
						}
					} else {
						tempHtml += '<b><a href="'+genLink(obj2[id3].link)+'" target="'+obj2[id3].target+'">' + obj2[id3].name + '</a></b>';
					}
				} else {
					if (obj2[id3].subSection) {
						tempHtml += '<a href="'+genLink(obj2[id3].link)+'" target="'+obj2[id3].target+'">' + obj2[id3].name + '</a>';
						tempHtml += ' > ';
						
						var obj3 = obj2[id3].subSection;
						tempHtml += '<b><a href="'+genLink(obj3[id4].link)+'" target="'+obj3[id4].target+'">' + obj3[id4].name + '</a></b>';
					} else {
						tempHtml += '<b><a href="'+genLink(obj2[id3].link)+'" target="'+obj2[id3].target+'">' + obj2[id3].name + '</a></b>';
					}
				}
			} else {
				tempHtml += '<b><a href="'+genLink(obj1[id2].link)+'" target="'+obj1[id2].target+'">' + obj1[id2].name + '</a></b>';
			}
		}
	}
	
	tempHtml += '</td>';
	
	tempHtml += '<td align="right" style="padding:0px 15px 0px 15px;">';
	tempHtml += '<table border="0" cellspacing="0" cellpadding="0" id="backBtn">';
	tempHtml += '<tr valign="top">';
	tempHtml += '<td style="padding:4px 4px 0px 0px;"><img src="'+path+'images/arrow_2.gif"></td>';
	tempHtml += '<td style="padding:0px 0px 0px 0px;" class="functionTxt" nowrap><a href="javascript:history.back();">��^</a></td>';
	tempHtml += '</tr>';
	tempHtml += '</table>';
	tempHtml += '</td>';
	
	tempHtml += '</tr>';
	
	if (padding > 0) {
		tempHtml += '<tr><td height="'+padding+'"><img src="'+path+'images/spacer.gif"></td></tr>';
	}
	tempHtml += '</table>';
	
	document.getElementById('treeLinkDiv').innerHTML = tempHtml;
}
