<!--

function GetParam(name)
{
	var start=location.search.indexOf("?"+name+"=");
	if (start<0) start=location.search.indexOf("&"+name+"=");
 	if (start<0) return '';
 	start += name.length+2;
 	var end=location.search.indexOf("&",start)-1;
 	if (end<0) end=location.search.length;
 	var result=location.search.substring(start,end);
 	var result='';
 	for(var i=start;i<=end;i++)
 	{
 		var c=location.search.charAt(i);
 		result=result+(c=='+'?' ':c);
 	}
 	//alert(unescape(result));
 	return unescape(result);
}


function changeLanguage() {
	var target = 'en';
	var nowL = 'ch';
	var topL = '#top';
	var url = '';
	var hasTopInUrl = document.URL.indexOf(topL)
	if (hasTopInUrl == -1) {
		url = location.href.replace((nowL+'/'), (target+'/'));
	} else {
		url = location.href.replace((nowL+'/'), (target+'/'));
		url = url.replace(topL, '');
	}
	location.href = url;
}


function NewWindow(mypage, myname, w, h, scroll,resizable) {
	var winl = (screen.width - w) / 2;
	var wint = (screen.height - h) / 2;
	winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable='+resizable+','
	win = window.open(mypage, myname, winprops)
	win.self.focus()
	if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}

function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}

function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function genFlash(file, width, height, id, vars) {
	var tempHtml = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="'+width+'" height="'+height+'" id="'+id+'" name="'+id+'">';
	tempHtml += '<param name="movie" value="'+file+'">';
	tempHtml += '<param name="quality" value="high">';
	tempHtml += '<param name="menu" value="false">';
	tempHtml += '<param name="wmode" value="opaque">';
	tempHtml += '<param name="scale" value="noscale">';
	tempHtml += '<param name="salign" value="TL">';
	
	if (vars != null) {
		tempHtml += '<param name="flashVars" value="'+vars+'">';
		tempHtml += '<embed src="'+file+'" flashVars="'+vars+'" salign="TL" quality="high" scale="noscale" wmode="opaque" menu="false" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="'+width+'" height="'+height+'" id="'+id+'" name="'+id+'"></embed>';
	} else {
		tempHtml += '<embed src="'+file+'" salign="TL" quality="high" scale="noscale" wmode="opaque" menu="false" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="'+width+'" height="'+height+'" id="'+id+'" name="'+id+'"></embed>';
	}
	
	tempHtml += '</object>';
	
	document.write(tempHtml);
}


var popUpPage2;

function popupFlash(file, w, h, name, vars) {
 if (popUpPage2)	popUpPage2.close();
 
 popUpPage2 = window.open('', ''+name+'', 'width='+w+',height='+h+',left=0,top=0,screenX=0,screenY=0,scrollbars=0,resizable=0');
 popUpPage2.document.open();
 popUpPage2.document.write('<html>');
 popUpPage2.document.write('<head><title>The Hong Kong Jockey Club</title></head>');
 popUpPage2.document.write('<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">');
 popUpPage2.document.write('	<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="'+w+'" height="'+h+'" id="'+name+'" name="'+name+'">');
 popUpPage2.document.write('	<param name="allowScriptAccess" value="always">');
 popUpPage2.document.write('	<param name="movie" value="'+file+'">');
 popUpPage2.document.write('	<param name="quality" value="high">');
 popUpPage2.document.write('	<param name="menu" value="false">');
	
	if (vars != null) {
 		popUpPage2.document.write('	<param name="flashVars" value="'+vars+'">');
 		popUpPage2.document.write('	<embed src="'+file+'" allowScriptAccess="always" flashVars="'+vars+'" quality="high" menu="false" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="'+w+'" height="'+h+'" id="'+name+'" name="'+name+'"></embed>');
	} else {
 		popUpPage2.document.write('	<embed src="'+file+'" allowScriptAccess="always" quality="high" scale="noscale" menu="false" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="'+w+'" height="'+h+'" id="'+name+'" name="'+name+'"></embed>');
	}
	
 	popUpPage2.document.write('	</object>');
 popUpPage2.document.write('</body>');
 popUpPage2.document.write('</html>');
 popUpPage2.document.close();
 popUpPage2.focus();
}

//Specify affected tags. Add or remove from list:
var tgs = new Array('span', 'td', 'strong', 'a', 'li', 'div');
var startSz;

function getFontSize(trgt) {
	if (document.cookie.indexOf("fontSize") < 0) {
		startSz = 0;
	} else {
		var startStr = document.cookie.indexOf("fontSize") + 9;
		var endStr = document.cookie.indexOf(";", startStr);
		if (endStr == -1) {
			endStr = document.cookie.length;
		}
		startSz = unescape(document.cookie.substring(startStr, endStr));
		
//		alert(startSz);
		changeFontSize(trgt, startSz, true);
	}
}


function changeFontSize( trgt, inc, start ) {
	
	//Specify spectrum of different font sizes:
	var szs = new Array('12px', '13px', '16px', '18px');
	
	if (!document.getElementById) return;
	var d = document,cEl = null,sz = eval(startSz),i,j,cTags;
	
	if (!start) {
		sz += inc;
		//sz = inc;
		
		if ( sz < 0 ) sz = 0;
		if ( sz > (szs.length-1) ) sz = (szs.length-1);
		startSz = sz;
	//	alert(sz);
	} else {
		sz = inc;
	}
	
	if ( !( cEl = d.getElementById( trgt ) ) ) cEl = d.getElementsByTagName( trgt )[ 0 ];
	cEl.style.fontSize = szs[ sz ];
	
	setCookie("fontSize", sz, nd, cpath, cdomain);
	
	var temp;
	for ( i = 0 ; i < tgs.length ; i++ ) {
		cTags = cEl.getElementsByTagName( tgs[ i ] );
		for ( j = 0 ; j < cTags.length ; j++ ) {
			//alert(cTags[ j ].className);
			if (cTags[ j ].id == "boxTD")	return;
//			if (cTags[ j ].id != "boxTD") {
//			if (cTags[ j ].className.indexOf("box") == -1) {
//				temp += cTags[ j ].className + "\r";
				cTags[ j ].style.fontSize = szs[ sz ];
//			} else {
				//break;
			//	i ++;
//			}
		}
	}
//	alert (temp);
}

nd= new Date();
nd.setTime (nd.getTime()+(365*24*60*60*1000));
//cdomain = (location.domain) ? location.domain : null;
cdomain = (location.domain) ? location.domain : null;
cpath = "/";

function setCookie(name, value, expires, path, domain, secure) {
  var curCookie = name + "=" + escape(value) +
      ((expires) ? "; expires=" + expires.toGMTString() : "") +
      ((path) ? "; path=" + path : "") +
      ((domain) ? "; domain=" + domain : "") +
      ((secure) ? "; secure" : "");
  document.cookie = curCookie;
  //alert(curCookie);
}


function popupLink(mypage) {
	winprops = '';
	win = window.open(mypage, 'popupPage', winprops);
	win.self.focus();
//	if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}

function popupLinkWithTarget(mypage, target) {
	var winprops = '';
/*	if ((typeof(window.opener)!="undefined")
	&& (typeof(window.opener.location)!="unknown"))
		{
			window.opener.focus();
		}
	else
		{
			win = window.open(mypage, target, winprops);
			win.self.focus();
		}*/
	
	if (window.opener) {
		window.opener.location.href = mypage;
		window.opener.focus();
	} else {
		var win = window.open(mypage, target, winprops);
		win.self.focus();
	}
//	if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}


var isIE = true;
if (navigator.appName.indexOf("Microsoft") > -1) {
	isIE = true;
} else {
	isIE = false;
}

function rowClick(i) {
	var detailsTD = document.getElementById(('detail_'+i));
	
	if (!(detailsTD)) return;
	
	if (!detailsTD.clicked) {
		detailsTD.style.display = (isIE)?'block':'table-row-group';
		detailsTD.clicked = true;
	} else {
		detailsTD.style.display = 'none';
		detailsTD.clicked = false;
	}
}

// Fix page too long and can't jump to anchor problem
	theURL = window.location.href;
	if(theURL.indexOf("#") > -1) {
		theAnchor = theURL.split("#");
		setTimeout("document.location = '#'+theAnchor[1]",2000);
	}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

-->