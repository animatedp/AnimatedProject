﻿//Edited by DCHK at 18-3-2009 11:40am

var sectionArray = new Array();
var tempHtml;
var tempStr1;
var tempStr2;
if (section == null)	var section = 0;
if (level1 == null)	var level1 = "";
if (level2 == null)	var level2 = "";
if (level3 == null)	var level3 = "";
var id1 = null;
var id2 = null;
var id3 = null;
var imgPath = path + "images/";
var menuImgPath = path + "images/menu/";
var menuTop = "53";
var menuLeft = "177";

var color1 = "#5D92DB";
var color2 = "#0C4D96";

function getQuickLinksByElement(e)
{
	var nodes = e.childNodes;
	var linkItem = new quickLinks();
	
	for (var i=0; i<nodes.length; i++)
		{
			var node = nodes[i];
			for (var k in linkItem)
				{
					if (node.nodeName == k)
						{
							linkItem[k] = (node.firstChild)?node.firstChild.data:"";
						}
				}
		}
	return linkItem;
}

function getSectionByElement(e)
{
	var nodes = e.childNodes;
	var sub = new Array();
	var qlinks = new Array();
	var menuItem = new menu();
	var j = 0;
	var q = 0;
	
	for (var i=0; i<nodes.length; i++)
		{
			var node = nodes[i];
			for (var k in menuItem)
				{
					if (node.nodeName == k)
						{
							switch(node.nodeName)
								{
									case "subSection":
										sub[j++] = getSectionByElement(node);
										break;
									case "quickLinks":
										qlinks[q++] = getQuickLinksByElement(node);
										break;
									default:
										menuItem[k] = (node.firstChild)?node.firstChild.data:"";
										break;									
								}
						}
				}
			menuItem["subSection"] = sub;
			menuItem["quickLinks"] = qlinks;
		}
	return menuItem;
}

function genNav() {
	var sect = 0;
	var obj = sectionArray[section];
	var total = obj.length;
	
	tempHtml += '<div id="topNav" style="position:absolute; left:'+menuLeft+'px; top:'+menuTop+'px; width:570px;">';
	tempHtml += '<table width="570" cellpadding="0" cellspacing="0" border="0">';
	tempHtml += '<tr>';
	tempHtml += '<td>';
	tempHtml += '<table width="100%" cellpadding="0" cellspacing="0" border="0">';
	
	tempHtml += '<tr>';
	
	for (var i=0; i<total; i++) {
		if (sect == section && id1 == i) {
			isSect = 1;
		} else {
			isSect = 0;
		}
		
		tempStr1 = "";
		
		obj[i].width = (100/total) + "%";
		
		
		tempHtml += '<td width="'+obj[i].width+'" style="padding: 0px 0px 3px 0px; cursor:pointer;'+tempStr1+'" nowrap class="menu_nav">';
		//tempHtml += '<a href="'+genLink(obj[i].link, obj[i].popup, obj[i].target)+'" target="'+obj[i].target+'" class="menu_nav">'+obj[i].name.toUpperCase()+'</a>';
//		tempHtml += '<a href="'+genLink(obj[i].link, obj[i].popup, obj[i].target)+'" class="menu_nav">'+obj[i].name.toUpperCase()+'</a>';

		tempHtml += '<div style="position:absolute;">';
		tempHtml += '<div style="position:relative; width:'+obj[i].width+'px; height:35px;" onMouseOver="navOver('+i+', 1, '+isSect+');" onMouseOut="navOver('+i+', 0, '+isSect+'); setTimeout(function() {menuGo(0, 1);}, 200);" onClick="menuGo(1, 1,'+i+');">';
		tempHtml += '<img src="'+imgPath+'spacer.gif" width="'+(570/total)+'" height="30">';
		tempHtml += '</div>';
		tempHtml += '</div>';

		tempHtml += '<div style="text-align:center; padding-top:5px;">' + obj[i].name.toUpperCase() + '</div>';
		tempHtml += '</td>';
		
		if (i < (total-1))	tempHtml += '<td width="2" rowspan="2"><img src="'+imgPath+'spacer.gif" width="2" height="1"></td>';
		
	}
	
	tempHtml += '</tr>';
	
	tempHtml += '<tr>';
	for (var i=0; i<total; i++) {
		if (sect == section && id1 == i) {
			tempStr1 = "4E9BD4";
			isSect = 1;
		} else {
			tempStr1 = "365F93";
			isSect = 0;
		}
		tempHtml += '<td style="background-color:#'+tempStr1+';" id="navColor_'+i+'"><img src="'+imgPath+'spacer.gif" width="4" height="4"></td>';
	}
	tempHtml += '</tr>';
	tempHtml += '</table>';
	tempHtml += '</td>';
	tempHtml += '</tr>';
	
	tempHtml += '<tr><td style="padding-top:3px;">';
	genMenu();
	tempHtml += '</td></tr>';
	
	
	tempHtml += '</table>';
	tempHtml += '</div>';
}


var menuH = 350;

function genMenu() {
	var sect = 0;
	var obj = sectionArray[section];
	var total = obj.length;
	
	tempHtml += '<div style="position:absolute;">';
	tempHtml += '<div style="position:absolute; overflow:hidden; left:-2px; top:0px; width:575px; height:1px;" id="menuMask">';
	tempHtml += '<div id="navMenu" style="position:absolute; top:'+(-menuH)+'px; visibility:hidden;" onMouseOver="menuGo(1, 1);" onMouseOut="setTimeout(function() {menuGo(0, 1);}, 100);">';
	tempHtml += '<table width="575" cellpadding="0" cellspacing="0" border="0">';
	tempHtml += '<tr>';
	tempHtml += '<td style="border:2px #003B7E solid; padding:0px 0px 2px 0px; background-color:#E3E7F0;" id="menuTD">';
	
	tempHtml += '<table width="100%" cellpadding="0" cellspacing="0" border="0">';
	
	tempHtml += '<tr valign="top">';
	
	for (var i=0; i<total; i++) {
		tempHtml += '<td width="'+obj[i].width+'" id="menuBg_'+i+'" style="padding:5px 2px 5px 2px;" onMouseOver="navOver('+i+', 1, 0);" onMouseOut="navOver('+i+', 0, 0);">';
		
//		alert(i + " : " + obj[i] + " : " + obj[i].subSection.length);
		//subSection
		if (obj[i].subSection) {
			var obj1 = obj[i].subSection;
			tempHtml += '<table width="100%" cellspacing="0" border="0">';
			
			for (var j=0; j<obj1.length; j++) {
				//var t = '';
				//if (obj1[j].popup=="0") t = '" target="'+obj1[j].target;
				//if (obj1[j].popup=="0") t = ' target="_self"';

				tempHtml += '<tr>';
				tempHtml += '<td style="padding:4px 1px 4px 1px;" id="menuTxtTd_'+i+'_'+j+'" onMouseOver="menuTxtOver('+i+', '+j+', 1, 0);" onMouseOut="menuTxtOver('+i+', '+j+', 0, 0);">';
				tempHtml += '<a href="'+genLink(obj1[j].link, obj1[j].popup, obj1[j].target)+'" class="menu_menuTxt" id="menuTxt_'+i+'_'+j+'">'+obj1[j].name+'</a>';
				tempHtml += '</td>';
				 
				tempHtml += '</tr>';
			}
			
			tempHtml += '</table>';
		}
		
		
		tempHtml += '</td>';
		if (i < (total-1)) {
			tempHtml += '<td width="1" height="100%" valign="middle" style="padding:8px 0px 0px 1px;">';
			tempHtml += '<table width="1" height="100%" cellpadding="0" cellspacing="0" border="0" style="border-left:1px dotted #7388A3;">';
			tempHtml += '<tr>';
			tempHtml += '<td><img src="'+imgPath+'spacer.gif" width="1" height="1"></td>';
			tempHtml += '</tr>';
			tempHtml += '</table></td>';
		}
	}
	
	tempHtml += '</tr>';
	tempHtml += '</table>';
	tempHtml += '</td>';
	tempHtml += '</tr>';
	tempHtml += '</table>';
	
	//Promotion
	tempHtml += '<div style="position:absolute; left:235px; top:158px; width:352px; height:140px; overflow:hidden; visibility:hidden;" id="menuBox" onMouseOver="menuGo(1, 1);">';
	tempHtml += '<table width="100%" height="100%" cellpadding="3" cellspacing="0" border="0" bgcolor="#E3E7F0">';
	tempHtml += '<tr><td>';
	
	tempHtml += '<table width="100%" height="100%" cellpadding="5" cellspacing="0" border="0" bgcolor="#FAFBFC">';
	tempHtml += '<tr valign="top">';
	tempHtml += '<td rowspan="2" style="padding-top:10px;"><img src="'+imgPath+'spacer.gif" id="menuPic"></td>';
	tempHtml += '<td width="100%" class="menu_gray" id="menuTxt" style="line-height:18px; padding-top:10px;"></td>';
	tempHtml += '</tr>';
	tempHtml += '</table>';
	
	tempHtml += '</td></tr>';
	tempHtml += '</table>';
	tempHtml += '</div>';
	
	tempHtml += '</div>';
	tempHtml += '</div>';
}


var navIsOver = false;

function navOver(id, over, isSect) {
	var obj = sectionArray[section];

	if (isSect == 1) {
		//return;
	}
	
	for (var i=0; i<obj.length; i++) {
		var menuBg = document.getElementById('menuBg_'+i);
		menuBg.style.backgroundColor = '';

		var obj1 = obj[i].subSection;
		for (var j=0; j<obj1.length; j++) {
			var menuTxt = document.getElementById('menuTxt_'+i+'_'+j);
			menuTxt.style.color = '#002E65';
		}
		
		var navColor = document.getElementById(('navColor_'+i));
		if (i == id1) continue;
		navColor.style.backgroundColor = '#365F93';
	}
	
	var layer = document.getElementById('navMenu');
	var navColor = document.getElementById(('navColor_'+id));
	
	if (over == 1) {
		navIsOver = true;
		navColor.style.backgroundColor = '#4E9BD4';
		
		var obj1 = obj[id].subSection;
		for (var j=0; j<obj1.length; j++) {
			var menuTxt = document.getElementById('menuTxt_'+id+'_'+j);
			menuTxt.style.color = '#FFFFFF';
		}
		
		var menuBg = document.getElementById('menuBg_'+id);
		menuBg.style.backgroundColor = color1;
		
	} else {
		navIsOver = false;
		if (id == id1) return;
		navColor.style.backgroundColor = '#365F93';
	}
}


function menuTxtOver(i, j, over, isSect) {
	var obj = sectionArray[0][i].subSection[j];
	var nav = document.getElementById(('menuTxtTd_'+i+'_'+j));
	
	var menuPic = document.getElementById('menuPic');
	var menuTxt = document.getElementById('menuTxt');
	var menuBox = document.getElementById('menuBox');
	
	if (over == 1) {
		if (!isSect)	nav.style.backgroundColor = color2;
		
		if (obj.menuTxt != "") { // 20080122 declare value
			menuPic.src = menuImgPath+'pic_'+obj.id+'.gif';
			menuTxt.innerHTML = '<span class="menu_title">' + obj.name + '</span><br>' + obj.menuTxt;
			menuBox.style.visibility = 'visible';
		} else {
			if (menuBox.style.visibility != 'hidden') {
				menuPic.src = imgPath+'spacer.gif';
				menuTxt.innerHTML = "";
				menuBox.style.visibility = 'hidden';
			}
		}
	} else {
		if (!isSect)	nav.style.backgroundColor = '';
		if (menuBox.style.visibility != 'hidden') {
			menuPic.src = imgPath+'spacer.gif';
			menuTxt.innerHTML = "";
			menuBox.style.visibility = 'hidden';
		}
	}
}


function menuBgOver(id) {
	var obj = sectionArray;
	
	for (var i=0; i<obj.length; i++) {
		var menuBg = document.getElementById('menuBg_'+i);
		menuBg.style.backgroundColor = '';
		
		var obj1 = obj[i].subSection;
		for (var j=0; j<obj1.length; j++) {
			var menuTxt = document.getElementById('menuTxt_'+i+'_'+j);
			menuTxt.style.color = '#002E65';
		}
	}
	
	var obj1 = obj[id].subSection;
	for (var j=0; j<obj1.length; j++) {
		var menuTxt = document.getElementById('menuTxt_'+id+'_'+j);
		menuTxt.style.color = '#FFFFFF';
	}
	
	var menuBg = document.getElementById('menuBg_'+id);
	menuBg.style.backgroundColor = color1;
	
}


var goSpeed = 1;
var speed;
var goStep;
var timeOut;
var objTop;
var tempTop;
var layer;
var menuMask;


function menuGo(over, motion, newOpen) {
	layer = document.getElementById('navMenu');
	menuMask = document.getElementById('menuMask');
	
	if(newOpen == "3"){
        window.open("https://cc.hkjc.com/#?language=zh-ch","_blank");
	}else if (over) {
		if (layer)	layer.style.visibility = 'visible';
		
		if (navigator.appName.indexOf("Microsoft") > -1) {
			tempTop = -3;
			speed = 10;
			pulldownMotion();
		} else {
			layer.style.top = -3;
		}
		menuMask.style.height = menuH;
		menuMask.style.overflow = "visible"; //20160323 for IE9 issue
		
		mvqPHideEle(true);
	} else {
		if (navIsOver)	return;
		if (navigator.appName.indexOf("Microsoft") > -1) {
			tempTop = -menuH;
			speed = 4;
			timeOut = setTimeout('pulldownMotion();', 200);
		} else {
			layer.style.visibility = 'hidden';
			layer.style.top = -menuH;
			menuMask.style.height = 1;
		}
		
		var menuBox = document.getElementById('menuBox');
		if (menuBox.style.visibility != 'hidden')	menuBox.style.visibility = 'hidden';
		menuMask.style.overflow = "hidden"; //20160323 for IE9 issue
		
		mvqPHideEle(false);
	}
}


function layerOff() {
	layer.style.visibility = 'hidden';
}


function pulldownMotion() {
	objTop = Number(layer.style.pixelTop);
	
	goStep = (tempTop - objTop)/speed;
	
	if (objTop - tempTop > 1 | objTop - tempTop < -1) {
		objTop += goStep;
		timeOut = setTimeout("pulldownMotion()", goSpeed);
	} else {
		objTop = tempTop;
		clearTimeout(timeOut);
	}
	
	layer.style.pixelTop = objTop;
}



function genLink(i, p, t) {
	if (i.indexOf('http') > -1) {
		var link = i;
	} else if (i.indexOf('javascript') > -1) {
		var link = i;
	} else {
		var link = path + i;
	}
	//var link = i;
	
	switch (p)
		{
			case "1":
				link = "javascript:NewWindowS(\'" + link + "\',\'" + t + "\',770, 550, 1,0);";
				break;
			case "2":
				link = 'javascript:popupLinkNW(\'' + link + '\',\'' + t +'\');';
				break;
		}
	
	return link;
}


function menu(name,id,link,target,popup,logo,menuTxt,quickLink,subSection)
{
	this.name = (name)?name:"";
	
	this.id = (id)?id:"";
	this.link = (link)?link:"";
	this.target = (target)?target:"";
	this.popup = (popup)?popup:"0";
	this.menuTxt = (menuTxt)?menuTxt:"";
	//this.subSection = (subSection)?subSection:new Object();
	this.logo = (logo)?logo:"";
	this.quickLinks = (quickLink)?quickLink:new Array();
	this.subSection = (subSection)?subSection:new Array();
}

function quickLinks(name,link,target,popup,menuTxt)
{
	this.name = (name)?name:"";
	this.link = (link)?link:"";
	this.target = (target)?target:"";
	this.popup = (popup)?popup:"0";
	this.menuTxt = (menuTxt)?menuTxt:"";
}

function getXML()
{
	genMenuObject(path + 'xml/sbdata_userMenu.xml');
}
 
function genMenuObject(url) {	
	if (document.getElementById)
		{
			var x = (window.ActiveXObject) ? new ActiveXObject("Microsoft.XMLHTTP") : new XMLHttpRequest(); 
		}
	if (x)
		{
			x.onreadystatechange = function()
			{
				if (x.readyState == 4 && x.status == 200)
				{			
					
					var root = x.responseXML.getElementsByTagName('nav').item(0);
					var section = root.getElementsByTagName('section');
					var oldEwin = root.getElementsByTagName('oldEwin');
					
					sectionArray[0] = new Array();
					sectionArray[1] = new Array();
										
					for (var i=0; i< section.length; i++)
						{
							sectionArray[0][i] = getSectionByElement(section[i]);
						}
						
					for (var i=0; i< oldEwin.length; i++)
						{
							sectionArray[1][i] = getSectionByElement(oldEwin[i]);
						}
						
					getLevel();
					genId();
					
					genTop();
					genLeftStart();
					
					var bo = document.getElementsByTagName("BODY");
					var spans = document.getElementsByTagName("SPAN");
					if (spans["treeLinkDiv"]) genTreeLink();
					if (spans["titleDiv"]) genTitle();
					
					var tds = document.getElementsByTagName("TD");
					var tables = document.getElementsByTagName("TABLE");

					if (spans["logoImg"])
						{
							spans["logoImg"].innerHTML = '<img id="logoImg" src="'+path+level1+'/'+level2+'/images/logo.gif">';
						}
					if (tables["logoTable"])
						{
							tds['rightTD'].appendChild(tables["logoTable"]);
						}

					if (spans["treeLinkDiv"]) tds['rightTD'].appendChild(spans["treeLinkDiv"]);
					if (spans["titleDiv"]) tds['rightTD'].appendChild(spans["titleDiv"]);

					if (tables["contentTable"]) tds['rightTD'].appendChild(tables['contentTable']);
					if (tables["topBtn"]) tds['rightTD'].appendChild(tables["topBtn"]);
					
					var styles = root.getElementsByTagName('style');
					var attrs = ["left", "top", "height", "width"];
			
					for (var n=0; n< styles.length; n++)
						{
							var nodes = styles[n].childNodes;
							for (var i=0; i<nodes.length; i++)
								{
									var node = nodes[i];
									if (node.nodeName == "#text") continue;
									var sitem = document.getElementById(node.nodeName);
									var temp = "";
									for (var att in attrs)
										{
											sitem.style[attrs[att]] = node.getAttribute(attrs[att]);
										}
								}
						}
						
					bo[0].style.display = "block";
					
					var menuTD = document.getElementById('menuTD');
					menuH = menuTD.scrollHeight + 50;
					
					var menuBox = document.getElementById('menuBox');
					var tempH;
					if (navigator.appName.indexOf("Microsoft") > -1) {
						tempH = Number(menuBox.style.pixelHeight);
					} else {
						var tempH = menuBox.style.height;
						tempH = Number(tempH.substring(0, (tempH.length-2))) + 5;
					}
					menuBox.style.top =  menuTD.scrollHeight - tempH + "px";
					
					mvqPDiv = document.getElementById("navMenu");
					mvqPStyle = mvqPDiv.style;
					
					subNavStart(id3);
				}
			}
			
			x.open("GET", url, true);
			x.send(null);
		}

}

var tempStr = "";

function popupLinkNW(mypage, n) {
	winprops = '';
	win = window.open(mypage, n, winprops);
	win.self.focus();
}

function NewWindowS(mypage, myname, w, h, scroll,resizable) {
	var winl = (screen.width - w) / 2;
	var wint = (screen.height - h) / 2;
	winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable='+resizable+','
	win = window.open(mypage, myname, winprops)
	win.self.focus()
	if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}


var mvqTimeout = 125;
var mvqPDiv, mvqPStyle;


function mvqPHideEle(boolHide)
{
    window.setTimeout("mvqPHideEle1('OBJECT'," +  boolHide + ")", mvqTimeout);
    window.setTimeout("mvqPHideEle1('SELECT'," +  boolHide + ")", mvqTimeout+1);
}

function mvqPHideEle1(el, boolShowHide)
{
    var objects = document.getElementsByTagName(el);
    if(objects.length == 0) return;
    for(var i=0; i < objects.length; i++)
    {
        var obj = objects.item(i);
        elm = mvqPDiv.firstChild;
		//alert(elm);
        if(elm)
        {
            if(boolShowHide && mvqPVerifyOverlap(elm, obj))
            {
                obj.style.visibility = "hidden";
            }
            else
            {
                if(obj.style.visibility == "hidden") obj.style.visibility = "visible";
            }
        }
    }
}

function mvqPDimension(elm)
{
    var top = 0;
    var height = 0;
    var width = 0;
    var left = 0;
    if(elm)
    {
        this.height = elm.offsetHeight;
        this.width = elm.offsetWidth;
        while(elm)
        {
            left += elm.offsetLeft;
            top += elm.offsetTop;
            elm = elm.offsetParent;
        }
        this.left = left;
        this.top = top;
    }
}

function mvqPVerifyOverlap(tbl, overlapElm)
{
    var p1 = new mvqPDimension(overlapElm);
    var p = new mvqPDimension(tbl);
    return ( ((p.left + p.width) > p1.left) && (p.left < (p1.left + p1.width)) && (p.top < (p1.top - overlapElm.offsetTop + p1.height)) && ((p.top + p.height) > (p1.top - overlapElm.offsetTop)) );
}

